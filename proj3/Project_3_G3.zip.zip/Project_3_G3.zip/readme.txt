"""Filelist"""
"ccm.gds" --- CCM Layout file
"normal.gds" --- non-CCM Layout file
"pierre.pex.sp" --- CCM pex extracted .sp file
"pierre.pex.sp.PIERRE.pxi --- CCM pex extracted .pxi file
"pierre.pex.sp.pex" --- CCM pex extracted .pex file
"pierre_o.pex.sp" --- non-CCM pex extracted .sp file
"pierre_o.pex.sp.PIERRE_O.pxi" --- non-CCM pex extracted .pxi file
"pierre_o.pex.sp.pex" --- non-CCM pex extracted .pex file
"proj3_b.sp" --- SPICE netlist file
"Project_3_Report_G3.docx" --- Report and Analysis of this project
